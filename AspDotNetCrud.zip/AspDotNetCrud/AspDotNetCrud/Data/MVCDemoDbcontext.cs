﻿using AspDotNetCrud.Models.Domian;
using Microsoft.EntityFrameworkCore;

namespace AspDotNetCrud.Data
{
    public class MVCDemoDbcontext : DbContext
    {
        public MVCDemoDbcontext(DbContextOptions options) : base(options)
        {
        }
            public DbSet<Employee> Employees { get; set; }

    }
}

